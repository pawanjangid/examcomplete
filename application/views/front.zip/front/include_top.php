<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/magnific-popup.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/themify-icons.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/nice-select.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/flaticon.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/gijgo.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/animate.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/slicknav.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/style.css">